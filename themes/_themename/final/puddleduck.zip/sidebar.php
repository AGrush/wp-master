<!-- //html5 tag complimentary -->
<aside role="complementary">
    <!-- id of sidebar to load -->
    <?php dynamic_sidebar( 'primary-sidebar' ); ?>
</aside>