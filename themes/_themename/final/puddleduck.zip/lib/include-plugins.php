<?php

require_once get_template_directory() . '/lib/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'puddleduck_register_required_plugins' );

//the tgm activation settings, example info in class-tgm file in this folder
function puddleduck_register_required_plugins() {
    $plugins = array(
        array(
            'name' => 'puddleduck metaboxes',
            'slug' => 'puddleduck-metaboxes',
            'source' => get_template_directory_uri() . '/lib/plugins/puddleduck-metaboxes.zip',
            'required' => true,
            'version' => '1.0.0',
            //force install plugin?
            'force_activation' => false,
            'force_deactivation' => false,
        )
        // ,
        // array(
        //     'name' => 'puddleduck shortcodes',
        //     'slug' => 'puddleduck-shortcodes',
        //     'source' => get_template_directory_uri() . '/lib/plugins/puddleduck-shortcodes.zip',
        //     'required' => true,
        //     'version' => '1.0.0',
        //     'force_activation' => false,
        //     'force_deactivation' => false,
        // ),
        // array(
        //     'name' => 'puddleduck post types',
        //     'slug' => 'puddleduck-post-types',
        //     'source' => get_template_directory_uri() . '/lib/plugins/puddleduck-post-types.zip',
        //     'required' => true,
        //     'version' => '1.0.0',
        //     'force_activation' => false,
        //     'force_deactivation' => false,
        // )
    );

    $config = array(
        
    );

    tgmpa( $plugins, $config);
}