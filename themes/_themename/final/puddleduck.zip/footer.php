        <!-- close #content div -->
        </div>
        
        <footer id="footer" role="contentinfo">
            <!-- footer widgets template  -->
            <?php get_template_part( 'template-parts/footer/widgets'); ?>
            <!-- footer disclaimer template  -->
            <?php get_template_part( 'template-parts/footer/info'); ?>
        </footer>

        <?php wp_footer() ?>
    </body>
</html>