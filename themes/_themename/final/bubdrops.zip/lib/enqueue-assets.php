<?php 

//load main website css AND js assets
add_action('wp_enqueue_scripts', 'bubdrops_assets');
function bubdrops_assets(){
    //get_template_directory_uri() will always reference the parent theme
    wp_enqueue_style('bubdrops-stylesheet', get_template_directory_uri() . '/dist/assets/css/bundle.css', array(), '1.0.0', 'all');

 
    //add a plugin included in wp core: https://developer.wordpress.org/reference/functions/wp_enqueue_script/
    //wp_enqueue_script('jquery');

    // include this php so tat $inline_styles becomes available. Include always needs base path like this
    include(get_template_directory() . '/lib/inline-css.php');

    // handle1 - css style sheet that exists and we want to load handle2 css after
    wp_add_inline_style( 'bubdrops-stylesheet', $inline_styles );


    //include jquery in the array of dependancies here, (dependancies will load b4 script)
    wp_enqueue_script( 'bubdrops-scripts', get_template_directory_uri() . '/dist/assets/js/bundle.js', array('jquery'), '1.0.0', true );
}


//load admin page css AND js assets
add_action('admin_enqueue_scripts', 'bubdrops_admin_assets');
function bubdrops_admin_assets(){
    wp_enqueue_style('bubdrops-admin-stylesheet', get_template_directory_uri() . '/dist/assets/css/admin.css', array(), '1.0.0', 'all');
    wp_enqueue_script( 'bubdrops-admin-scripts', get_template_directory_uri() . '/dist/assets/js/admin.js', array(), '1.0.0', true );
};



// load login page css AND js assets
add_action( 'login_enqueue_scripts', 'bubdrops_login_assets' );
function bubdrops_login_assets() {
    wp_enqueue_style( 'bubdrops-login-stylesheet', get_template_directory_uri() . '/dist/assets/css/login.css', array(), '1.0.0', 'all');
    wp_enqueue_script( 'bubdrops-login-scripts', get_template_directory_uri() . '/dist/assets/js/login.js', array(), '1.0.0', true );
};


//customize api
add_action( 'customize_preview_init', 'bubdrops_customize_preview_js');
function bubdrops_customize_preview_js() {
    wp_enqueue_script( 'bubdrops-cutomize-preview', get_template_directory_uri() . '/dist/assets/js/customize-preview.js', array('customize-preview', 'jquery'), '1.0.0' , true );

    include(get_template_directory() . '/lib/inline-css.php');

    //MAKE PHP VARIABLE AVAILABLE TO JS, handle1- php variable(handle2) to be available in this file (so the handle2 js variable is injected before it in the index), handle2- object that will contain all of our variables that we want to pass from php to js, handle3- is an array of variables that we would like to be available in handle2 object for example we want inline_styles_sleelectors to be available under the name inline-css.
    wp_localize_script( 'bubdrops-cutomize-preview', 'bubdrops', array('inline-css' => $inline_styles_selectors) );
};




?>