<?php 

//load plugins admin page css AND js scripts
add_action('wp_enqueue_scripts', 'bubdrops_shortcodes_scripts');

function bubdrops_shortcodes_scripts(){
  wp_enqueue_script( 'bubdrops-shortcodes-scripts', plugins_url( 'bubdrops-shortcodes/dist/assets/js/bundle.js' ), array( 'jquery' ), '1.0.0', true);

  wp_enqueue_style( 'bubdrops-shortcodes-stylesheet',  plugins_url('bubdrops-shortcodes/dist/assets/css/bundle.css'), array(), '1.0.0', 'all' );
};
