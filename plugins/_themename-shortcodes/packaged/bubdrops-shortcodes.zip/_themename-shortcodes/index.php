<?php
/*
Plugin Name:  bubdrops shortcodes
Plugin URI: 
Description: Adding Shortcodes for bubdrops
Version: 1.0.0
Author: Andrey Grushevskiy
Author URI: 1-g.co.uk
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: bubdrops-shortcodes
Domain Path: /languages
*/

if( !defined('WPINC')) {
  die;
}

//when you define shortcodes you must add them in an action called 'init', when wp is initialised
function bubdrops_shortcodes_init() {
  include_once('includes/shortcodes/button/button.php');
}
add_action('init', 'bubdrops_shortcodes_init');

include_once('includes/enqueue-assets.php');