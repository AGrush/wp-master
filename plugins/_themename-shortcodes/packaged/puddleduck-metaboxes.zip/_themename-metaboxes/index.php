<?php
/*
Plugin Name:  puddleduck metaboxes
Plugin URI: 
Description: Adding Metaboxes for puddleduck
Version: 1.0.0
Author: Andrey Grushevskiy
Author URI: 1-g.co.uk
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: puddleduck-metaboxes
Domain Path: /languages
*/

if( !defined('WPINC')) {
  die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');